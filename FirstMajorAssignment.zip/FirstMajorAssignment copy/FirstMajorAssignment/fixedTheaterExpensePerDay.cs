﻿namespace FirstMajorAssignment
{
    internal class fixedTheaterExpensePerDay
    {
    }
}